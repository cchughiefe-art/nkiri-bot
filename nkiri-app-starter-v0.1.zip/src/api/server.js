require("dotenv").config();

const http = require("http");
const { URL } = require("url");
const {
  searchMovieX,
  getMovieXInfo,
  getMovieXSources,
  extractSeasons,
  formatSize
} = require("../providers/moviex");

const PORT = Number(process.env.API_PORT || process.env.PORT || 3001);
const HOST = process.env.API_HOST || "0.0.0.0";
const API_NAME = "TheNkiri App API";
const RATE_LIMIT_WINDOW_MS = 60_000;
const RATE_LIMIT_MAX = Number(process.env.API_RATE_LIMIT || 90);
const hits = new Map();

function send(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,OPTIONS",
    "access-control-allow-headers": "content-type,x-api-key"
  });
  res.end(body);
}

function ok(res, data, meta = undefined) {
  return send(res, 200, {
    status: "success",
    data,
    ...(meta ? { meta } : {})
  });
}

function fail(res, status, message, code = "ERROR") {
  return send(res, status, {
    status: "error",
    error: { code, message }
  });
}

function clientKey(req) {
  return String(
    req.headers["x-forwarded-for"] ||
      req.socket?.remoteAddress ||
      "unknown"
  ).split(",")[0].trim();
}

function rateAllowed(req) {
  const key = clientKey(req);
  const now = Date.now();
  const existing = hits.get(key);

  if (!existing || now - existing.startedAt >= RATE_LIMIT_WINDOW_MS) {
    hits.set(key, { startedAt: now, count: 1 });
    return true;
  }

  existing.count += 1;
  return existing.count <= RATE_LIMIT_MAX;
}

function subjectSummary(info) {
  const subject = info?.subject || {};
  return {
    id: String(subject.subjectId || ""),
    type: Number(subject.subjectType) === 2 ? "series" : "movie",
    title: subject.title || "Unknown title",
    description: subject.description || "",
    releaseDate: subject.releaseDate || null,
    year: Number(String(subject.releaseDate || "").slice(0, 4)) || null,
    durationSeconds: Number(subject.duration || 0),
    genre: subject.genre || "",
    country: subject.countryName || null,
    rating: Number(subject.imdbRatingValue || 0) || null,
    ratingCount: Number(subject.imdbRatingCount || 0) || 0,
    poster: subject?.cover?.url || subject.thumbnail || null,
    subtitles: subject.subtitles || "",
    hasResource: subject.hasResource !== false,
    trailer: subject?.trailer?.videoAddress?.url || null
  };
}

function sourceSummary(source) {
  return {
    quality: Number(source.quality || 0),
    size: Number(source.size || 0),
    sizeText: source.size ? formatSize(source.size) : "",
    format: source.format || "mp4",
    url: source.downloadUrl || source.directUrl || null
  };
}

function pickQuality(sources, requestedQuality) {
  const list = Array.isArray(sources) ? sources.filter(Boolean) : [];
  if (!list.length) return null;

  const q = Number(requestedQuality || 0);
  if (q > 0) {
    const exact = list.find(source => Number(source.quality) === q);
    if (exact) return exact;

    return [...list].sort(
      (a, b) => Math.abs(Number(a.quality || 0) - q) - Math.abs(Number(b.quality || 0) - q)
    )[0];
  }

  return [...list].sort((a, b) => Number(b.quality || 0) - Number(a.quality || 0))[0];
}

async function handle(req, res) {
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "access-control-allow-origin": "*",
      "access-control-allow-methods": "GET,OPTIONS",
      "access-control-allow-headers": "content-type,x-api-key"
    });
    return res.end();
  }

  if (req.method !== "GET") {
    return fail(res, 405, "Only GET is supported in v1.", "METHOD_NOT_ALLOWED");
  }

  if (!rateAllowed(req)) {
    return fail(res, 429, "Too many requests. Try again shortly.", "RATE_LIMITED");
  }

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const pathname = url.pathname.replace(/\/+$/, "") || "/";

  if (pathname === "/" || pathname === "/health") {
    return ok(res, {
      name: API_NAME,
      version: "1.0.0",
      online: true,
      provider: "moviex"
    });
  }

  if (pathname === "/api/search") {
    const q = String(url.searchParams.get("q") || "").trim();
    if (q.length < 2) {
      return fail(res, 400, "Query must contain at least 2 characters.", "BAD_QUERY");
    }

    const results = await searchMovieX(q);
    return ok(
      res,
      results.map(item => ({
        id: String(item.moviexId || ""),
        title: item.title,
        displayTitle: item.cleanTitle || item.title,
        year: item.year || null,
        type: item.type,
        poster: item.image || null,
        rating: Number(item.rating || 0) || null,
        genre: item.genre || "",
        provider: "moviex"
      })),
      { count: results.length, query: q }
    );
  }

  let match = pathname.match(/^\/api\/title\/(\d+)$/);
  if (match) {
    const id = match[1];
    const info = await getMovieXInfo(id);
    return ok(res, {
      ...subjectSummary(info),
      seasons: extractSeasons(info)
    });
  }

  match = pathname.match(/^\/api\/title\/(\d+)\/seasons$/);
  if (match) {
    const id = match[1];
    const info = await getMovieXInfo(id);
    return ok(res, {
      title: info?.subject?.title || "Series",
      seasons: extractSeasons(info)
    });
  }

  match = pathname.match(/^\/api\/title\/(\d+)\/episodes$/);
  if (match) {
    const id = match[1];
    const seasonNumber = Number(url.searchParams.get("season") || 0);
    if (!seasonNumber) {
      return fail(res, 400, "season is required.", "SEASON_REQUIRED");
    }

    const info = await getMovieXInfo(id);
    const seasons = extractSeasons(info);
    const season = seasons.find(item => Number(item.season) === seasonNumber);

    if (!season) {
      return fail(res, 404, "Season not found.", "SEASON_NOT_FOUND");
    }

    const episodes = Array.from({ length: season.maxEp }, (_, index) => ({
      season: seasonNumber,
      episode: index + 1,
      label: `S${String(seasonNumber).padStart(2, "0")}E${String(index + 1).padStart(2, "0")}`
    }));

    return ok(res, {
      id,
      title: info?.subject?.title || "Series",
      season: seasonNumber,
      episodes
    });
  }

  match = pathname.match(/^\/api\/source\/(\d+)$/);
  if (match) {
    const id = match[1];
    const season = Number(url.searchParams.get("season") || 0);
    const episode = Number(url.searchParams.get("episode") || 0);
    const quality = Number(url.searchParams.get("quality") || 0);

    if ((season && !episode) || (!season && episode)) {
      return fail(
        res,
        400,
        "season and episode must be supplied together.",
        "BAD_EPISODE_REQUEST"
      );
    }

    const result = await getMovieXSources(id, season, episode);
    const sources = result.sources.map(sourceSummary);
    const selected = pickQuality(result.sources, quality);

    if (!selected) {
      return fail(res, 404, "No downloadable source found.", "NO_SOURCE");
    }

    return ok(res, {
      id,
      season: season || null,
      episode: episode || null,
      requestedQuality: quality || null,
      selected: sourceSummary(selected),
      sources,
      captions: result.captions || [],
      limited: result.limited === true,
      hasResource: result.hasResource !== false
    });
  }

  return fail(res, 404, "Route not found.", "NOT_FOUND");
}

const server = http.createServer((req, res) => {
  handle(req, res).catch(error => {
    console.error("API ERROR:", error);
    if (!res.headersSent) {
      fail(res, 502, error?.message || "Provider request failed.", "PROVIDER_ERROR");
    } else {
      res.end();
    }
  });
});

server.listen(PORT, HOST, () => {
  console.log(`${API_NAME} listening on http://${HOST}:${PORT}`);
});

module.exports = { server };
